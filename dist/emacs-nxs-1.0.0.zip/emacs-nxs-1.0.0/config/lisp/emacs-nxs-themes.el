;;; emacs-nxs-themes.el --- Custom color themes based on Modus  -*- lexical-binding: t; -*-
;;
;; Author: Rahul Martim Juliato
;; URL: https://github.com/LionyxML/emacs-solo
;; Package-Requires: ((emacs "30.1"))
;; Keywords: faces, themes
;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:
;;
;; Custom color theme overrides for `modus-themes' providing
;; Catppuccin Mocha, SystemCrafters, GITS, and Matrix palettes.

;;; Code:

;;;  Cattpuccin Mocha Based Theme (hacked Modus)
;;
;; This tries to follow: https://github.com/catppuccin/catppuccin/blob/main/docs/style-guide.md
;; With the colors from: https://github.com/catppuccin/catppuccin/ (Mocha)
(use-package modus-themes
  :if (eq emacs-nxs-use-custom-theme 'catppuccin)
  :ensure nil
  :defer t
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts nil)
  (modus-themes-common-palette-overrides
   `((accent-0 "#89b4fa")
     (accent-1 "#89dceb")
     (bg-active bg-main)
     (bg-added "#364144")
     (bg-added-refine "#4a5457")
     (bg-changed "#3e4b6c")
     (bg-changed-refine "#515d7b")
     (bg-completion "#45475a")
     (bg-completion-match-0 "#1e1e2e")
     (bg-completion-match-1 "#1e1e2e")
     (bg-completion-match-2 "#1e1e2e")
     (bg-completion-match-3 "#1e1e2e")
     (bg-hl-line "#2a2b3d")
     (bg-hover-secondary "#585b70")
     (bg-line-number-active unspecified)
     (bg-line-number-inactive "#1e1e2e")
     (bg-main "#1e1e2e")
     (bg-mark-delete "#443245")
     (bg-mark-select "#3e4b6c")
     (bg-mode-line-active "#181825")
     (bg-mode-line-inactive "#181825")
     (bg-prominent-err "#443245")
     (bg-prompt unspecified)
     (bg-prose-block-contents "#313244")
     (bg-prose-block-delimiter bg-prose-block-contents)
     (bg-region "#585b70")
     (bg-removed "#443245")
     (bg-removed-refine "#574658")
     (bg-tab-bar      "#1e1e2e")
     (bg-tab-current  bg-main)
     (bg-tab-other    "#181825")
     (border-mode-line-active nil)
     (border-mode-line-inactive nil)
     (builtin "#89b4fa")
     (comment "#9399b2")
     (constant  "#f38ba8")
     (cursor  "#f5e0dc")
     (date-weekday "#89b4fa")
     (date-weekend "#fab387")
     (docstring "#a6adc8")
     (err     "#f38ba8")
     (fg-active fg-main)
     (fg-completion "#cdd6f4")
     (fg-completion-match-0 "#89b4fa")
     (fg-completion-match-1 "#f38ba8")
     (fg-completion-match-2 "#a6e3a1")
     (fg-completion-match-3 "#fab387")
     (fg-heading-0 "#f38ba8")
     (fg-heading-1 "#fab387")
     (fg-heading-2 "#f9e2af")
     (fg-heading-3 "#a6e3a1")
     (fg-heading-4 "#74c7ec")
     (fg-line-number-active "#b4befe")
     (fg-line-number-inactive "#7f849c")
     (fg-link  "#89b4fa")
     (fg-main "#cdd6f4")
     (fg-mark-delete "#f38ba8")
     (fg-mark-select "#89b4fa")
     (fg-mode-line-active "#bac2de")
     (fg-mode-line-inactive "#585b70")
     (fg-prominent-err "#f38ba8")
     (fg-prompt "#cba6f7")
     (fg-prose-block-delimiter "#9399b2")
     (fg-prose-verbatim "#a6e3a1")
     (fg-region "#cdd6f4")
     (fnname    "#89b4fa")
     (fringe "#1e1e2e")
     (identifier "#cba6f7")
     (info    "#94e2d5")
     (keyword   "#cba6f7")
     (keyword "#cba6f7")
     (name "#89b4fa")
     (number "#fab387")
     (property "#89b4fa")
     (string "#a6e3a1")
     (type      "#f9e2af")
     (variable  "#fab387")
     (warning "#f9e2af")))
  :config
  (modus-themes-with-colors
    (custom-set-faces
     `(change-log-acknowledgment ((,c :foreground "#b4befe")))
     `(change-log-date ((,c :foreground "#a6e3a1")))
     `(change-log-name ((,c :foreground "#fab387")))
     `(diff-context ((,c :foreground "#89b4fa")))
     `(diff-file-header ((,c :foreground "#f5c2e7")))
     `(diff-header ((,c :foreground "#89b4fa")))
     `(diff-hunk-header ((,c :foreground "#fab387")))
     `(gnus-button ((,c :foreground "#8aadf4")))
     `(gnus-group-mail-3 ((,c :foreground "#8aadf4")))
     `(gnus-group-mail-3-empty ((,c :foreground "#8aadf4")))
     `(gnus-header-content ((,c :foreground "#7dc4e4")))
     `(gnus-header-from ((,c :foreground "#cba6f7")))
     `(gnus-header-name ((,c :foreground "#a6e3a1")))
     `(gnus-header-subject ((,c :foreground "#8aadf4")))
     `(log-view-message ((,c :foreground "#b4befe")))
     `(match ((,c :background "#3e5768" :foreground "#cdd6f5")))
     `(modus-themes-search-current ((,c :background "#f38ba8" :foreground "#11111b" ))) ;; :foreground "#cdd6f4" -- Catppuccin default, not that visible...
     `(modus-themes-search-lazy ((,c :background "#3e5768" :foreground "#cdd6f5")))     ;; :foreground "#cdd6f4" :background "#94e2d5" -- Catppuccin default, not that visible...
     `(newsticker-extra-face ((,c :foreground "#9399b2" :height 0.8 :slant italic)))
     `(newsticker-feed-face ((,c :foreground "#f38ba8" :height 1.2 :weight bold)))
     `(newsticker-treeview-face ((,c :foreground "#cdd6f4")))
     `(newsticker-treeview-selection-face ((,c :background "#3e5768" :foreground "#cdd6f5")))
     `(tab-bar ((,c :background "#181825" :foreground "#bac2de")))
     `(tab-bar-tab ((,c :background "#1e1e2e" :underline nil)))
     `(tab-bar-tab-inactive ((,c :background "#181825" :foreground "#00ff00")))
     `(tab-bar-tab-group-current ((,c :background "#1e1e2e" :foreground "#bac2de" :underline t)))
     `(tab-bar-tab-group-inactive ((,c :background "#1e1e2e" :foreground "#9399b2")))
     `(vc-dir-file ((,c :foreground "#89b4fa")))
     `(vc-dir-header-value ((,c :foreground "#b4befe")))))
  :init
  (load-theme 'modus-vivendi t))


;;;  #SystemCrafters  Based Theme (hacked Modus)
(use-package modus-themes
  :if (eq emacs-nxs-use-custom-theme 'crafters)
  :ensure nil
  :defer t
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts nil)
  (modus-themes-common-palette-overrides
   `((accent-0 "#a1bfff")
     (accent-1 "#79a8ff")
     (bg-active bg-main)
     (bg-added "#2a3b2e")
     (bg-added-refine "#384c3f")
     (bg-changed "#3c435e")
     (bg-changed-refine "#4f5875")
     (bg-completion "#2f447f")
     (bg-completion-match-0 bg-main)
     (bg-completion-match-1 bg-main)
     (bg-completion-match-2 bg-main)
     (bg-completion-match-3 bg-main)
     (bg-hl-line "#30344a")
     (bg-hover-secondary "#676e95")
     (bg-line-number-active unspecified)
     (bg-line-number-inactive "#292d3e")
     (bg-main "#292d3e")
     (bg-mark-delete "#4d2d2d")
     (bg-mark-select "#3c435e")
     (bg-mode-line-active "#232635")
     (bg-mode-line-inactive "#282c3d")
     (bg-prominent-err "#4d2d2d")
     (bg-prompt unspecified)
     (bg-prose-block-contents "#232635")
     (bg-prose-block-delimiter bg-prose-block-contents)
     (bg-region "#3c435e")
     (bg-removed "#4d2d2d")
     (bg-removed-refine "#603939")
     (bg-tab-bar      "#232635")
     (bg-tab-current  bg-main)
     (bg-tab-other    "#232635")
     (border-mode-line-active nil)
     (border-mode-line-inactive nil)
     (builtin "#82aaff")
     (comment "#676e95")
     (constant  "#f78c6c")
     (cursor  "#eeffff")
     (date-weekday "#82aaff")
     (date-weekend "#f78c6c")
     (docstring "#8d92af")
     (err     "#ff5370")
     (fg-active fg-main)
     (fg-completion "white")
     (fg-completion-match-0 "#82aaff")
     (fg-completion-match-1 "#ff5370")
     (fg-completion-match-2 "#c3e88d")
     (fg-completion-match-3 "#f78c6c")
     (fg-heading-0 "#82aaff")
     (fg-heading-1 "#82aaff")
     (fg-heading-2 "#c792ea")
     (fg-heading-3 "#bb80b3")
     (fg-heading-4 "#a1bfff")
     (fg-line-number-active fg-main)
     (fg-line-number-inactive "gray50")
     (fg-link  "#82aaff")
     (fg-main "#eeffff")
     (fg-mark-delete "#ff5370")
     (fg-mark-select "#82aaff")
     (fg-mode-line-active "#a6accd")
     (fg-mode-line-inactive "#676e95")
     (fg-prominent-err "#ff5370")
     (fg-prompt "#c792ea")
     (fg-prose-block-delimiter "#676e95")
     (fg-prose-verbatim "#c3e88d")
     (fg-region "white")
     (fnname    "#82aaff")
     (fringe "#292d3e")
     (identifier "#c792ea")
     (info    "#89ddff")
     (keyword   "#89ddff")
     (name "#82aaff")
     (number "#f78c6c")
     (property "#82aaff")
     (string "#c3e88d")
     (type      "#c792ea")
     (variable  "#c792ea")
     (warning "#ffcb6b")))
  :config
  (modus-themes-with-colors
    (custom-set-faces
     `(change-log-acknowledgment ((,c :foreground "#a1bfff")))
     `(change-log-date ((,c :foreground "#c3e88d")))
     `(change-log-name ((,c :foreground "#f78c6c")))
     `(diff-context ((,c :foreground "#82aaff")))
     `(diff-file-header ((,c :foreground "#bb80b3")))
     `(diff-header ((,c :foreground "#82aaff")))
     `(diff-hunk-header ((,c :foreground "#f78c6c")))
     `(gnus-button ((,c :foreground "#82aaff")))
     `(gnus-group-mail-3 ((,c :foreground "#82aaff")))
     `(gnus-group-mail-3-empty ((,c :foreground "#82aaff")))
     `(gnus-header-content ((,c :foreground "#89ddff")))
     `(gnus-header-from ((,c :foreground "#c792ea")))
     `(gnus-header-name ((,c :foreground "#c3e88d")))
     `(gnus-header-subject ((,c :foreground "#82aaff")))
     `(log-view-message ((,c :foreground "#a1bfff")))
     `(match ((,c :background "#3c435e" :foreground "#eeffff")))
     `(modus-themes-search-current ((,c :background "#ff5370" :foreground "#292d3e" )))
     `(modus-themes-search-lazy ((,c :background "#3c435e" :foreground "#eeffff")))
     `(newsticker-extra-face ((,c :foreground "#8d92af" :height 0.8 :slant italic)))
     `(newsticker-feed-face ((,c :foreground "#ff5370" :height 1.2 :weight bold)))
     `(newsticker-treeview-face ((,c :foreground "#eeffff")))
     `(newsticker-treeview-selection-face ((,c :background "#3c435e" :foreground "#eeffff")))
     `(tab-bar ((,c :background "#232635" :foreground "#a6accd")))
     `(tab-bar-tab ((,c :background "#292d3e")))
     `(tab-bar-tab-group-current ((,c :background "#292d3e" :foreground "#a6accd")))
     `(tab-bar-tab-group-inactive ((,c :background "#232635" :foreground "#777")))
     `(tab-bar-tab-inactive ((,c :background "#232635" :foreground "#676e95")))
     `(vc-dir-file ((,c :foreground "#82aaff")))
     `(vc-dir-header-value ((,c :foreground "#a1bfff")))))
  :init
  (load-theme 'modus-vivendi-tinted t))

;;;  GITS             Based Theme (hacked Modus)
(use-package modus-themes
  :if (eq emacs-nxs-use-custom-theme 'gits)
  :ensure nil
  :defer t
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts nil)
  (modus-themes-common-palette-overrides
   `((accent-0 "#00e5ff")           ; neon cyan
     (accent-1 "#ff0044")           ; hot pink
     (bg-active bg-main)
     (bg-added "#0a2018")
     (bg-added-refine "#143a22")
     (bg-changed "#0a1e38")
     (bg-changed-refine "#142840")
     (bg-completion "#0a1a2a")
     (bg-completion-match-0 "#050810")
     (bg-completion-match-1 "#050810")
     (bg-completion-match-2 "#050810")
     (bg-completion-match-3 "#050810")
     (bg-hl-line "#0d1e2e")
     (bg-hover-secondary "#0d2030")
     (bg-line-number-active unspecified)
     (bg-line-number-inactive "#050810")
     (bg-main "#050810")            ; deep space
     (bg-mark-delete "#2a0a14")
     (bg-mark-select "#0a1e38")
     (bg-mode-line-active "#0a1628")
     (bg-mode-line-inactive "#080c16")
     (bg-prominent-err "#2a0a14")
     (bg-prompt unspecified)
     (bg-prose-block-contents "#0d1628")
     (bg-prose-block-delimiter bg-prose-block-contents)
     (bg-region "#0d2840")
     (bg-removed "#2a0a14")
     (bg-removed-refine "#3a1020")
     (bg-tab-bar      "#050810")
     (bg-tab-current  "#080c16")
     (bg-tab-other    "#050810")
     (border-mode-line-active nil)
     (border-mode-line-inactive nil)
     (builtin "#00e5ff")            ; neon cyan
     (comment "#2d5a70")            ; dim teal — recedes like noise
     (constant "#ff4466")           ; hot pink
     (cursor "#00e5ff")
     (date-weekday "#00e5ff")
     (date-weekend "#ffaa00")
     (docstring "#4a7a8a")          ; slightly brighter than comment
     (err "#ff0044")
     (fg-active fg-main)
     (fg-completion "#8ecede")
     (fg-completion-match-0 "#00e5ff")
     (fg-completion-match-1 "#ff0044")
     (fg-completion-match-2 "#00cc77")
     (fg-completion-match-3 "#ffaa00")
     (fg-heading-0 "#ff0044")
     (fg-heading-1 "#ff4466")
     (fg-heading-2 "#ffaa00")
     (fg-heading-3 "#00cc77")
     (fg-heading-4 "#00e5ff")
     (fg-line-number-active "#00e5ff")
     (fg-line-number-inactive "#1a3a50")
     (fg-link "#00e5ff")
     (fg-main "#68b8cc")            ; teal-grey
     (fg-mark-delete "#ff0044")
     (fg-mark-select "#00e5ff")
     (fg-mode-line-active "#8ecede")
     (fg-mode-line-inactive "#2a4a5a")
     (fg-prominent-err "#ff0044")
     (fg-prompt "#cc55ff")          ; purple
     (fg-prose-block-delimiter "#1a3a50")
     (fg-prose-verbatim "#00cc77")
     (fg-region "#8ecede")
     (fnname "#00c5dd")
     (fringe "#050810")
     (identifier "#cc55ff")         ; purple
     (info "#00cc77")
     (keyword "#cc55ff")            ; purple
     (name "#00e5ff")
     (number "#ffaa00")             ; amber
     (property "#00b8cc")
     (string "#00cc77")             ; neon green
     (type "#ffaa00")               ; amber
     (variable "#ff8800")           ; orange
     (warning "#ffaa00")))
  :config
  (modus-themes-with-colors
    (custom-set-faces
     `(change-log-acknowledgment ((,c :foreground "#00e5ff")))
     `(change-log-date ((,c :foreground "#00cc77")))
     `(change-log-name ((,c :foreground "#ffaa00")))
     `(diff-context ((,c :foreground "#1a3a50")))
     `(diff-file-header ((,c :foreground "#ff4466")))
     `(diff-header ((,c :foreground "#00e5ff")))
     `(diff-hunk-header ((,c :foreground "#ffaa00")))
     `(gnus-button ((,c :foreground "#00e5ff")))
     `(gnus-group-mail-3 ((,c :foreground "#00e5ff")))
     `(gnus-group-mail-3-empty ((,c :foreground "#00e5ff")))
     `(gnus-header-content ((,c :foreground "#68b8cc")))
     `(gnus-header-from ((,c :foreground "#cc55ff")))
     `(gnus-header-name ((,c :foreground "#00cc77")))
     `(gnus-header-subject ((,c :foreground "#00e5ff")))
     `(log-view-message ((,c :foreground "#00e5ff")))
     `(match ((,c :background "#0d2840" :foreground "#8ecede")))
     `(modus-themes-search-current ((,c :background "#ff0044" :foreground "#050810")))
     `(modus-themes-search-lazy ((,c :background "#0d2840" :foreground "#8ecede")))
     `(newsticker-extra-face ((,c :foreground "#1a3a50" :height 0.8 :slant italic)))
     `(newsticker-feed-face ((,c :foreground "#ff0044" :height 1.2 :weight bold)))
     `(newsticker-treeview-face ((,c :foreground "#68b8cc")))
     `(newsticker-treeview-selection-face ((,c :background "#0d2840" :foreground "#8ecede")))
     `(tab-bar ((,c :background "#050810" :foreground "#2a4a5a")))
     `(tab-bar-tab ((,c :background "#080c16" :underline nil)))
     `(tab-bar-tab-inactive ((,c :background "#050810" :foreground "#1a3a50")))
     `(tab-bar-tab-group-current ((,c :background "#080c16" :foreground "#68b8cc" :underline t)))
     `(tab-bar-tab-group-inactive ((,c :background "#050810" :foreground "#2a4a5a")))
     `(vc-dir-file ((,c :foreground "#00e5ff")))
     `(vc-dir-header-value ((,c :foreground "#68b8cc")))))
  :init
  (load-theme 'modus-vivendi t))

;;;  Matrix           Based Theme (hacked Modus)
(use-package modus-themes
  :if (eq emacs-nxs-use-custom-theme 'matrix)
  :ensure nil
  :defer t
  :custom
  (modus-themes-italic-constructs t)
  (modus-themes-bold-constructs t)
  (modus-themes-mixed-fonts nil)

  ;; MATRIX COLOR SCHEME OVERRIDES
  (modus-themes-common-palette-overrides
   `(
     ;; accents → bright greens
     (accent-0 "#00ff41")      ; malachite
     (accent-1 "#008f11")      ; islamic green
     ;; backgrounds
     (bg-active bg-main)
     (bg-added "#003b00")              ; dark green
     (bg-added-refine "#005a00")       ; slightly brighter
     (bg-changed "#004800")
     (bg-changed-refine "#006600")
     (bg-completion "#0d0208")         ; vampire black
     (bg-completion-match-0 "#0d0208")
     (bg-completion-match-1 "#0d0208")
     (bg-completion-match-2 "#0d0208")
     (bg-completion-match-3 "#0d0208")
     (bg-hl-line "#002200")
     (bg-hover-secondary "#003b00")
     (bg-line-number-active unspecified)
     (bg-line-number-inactive "#0d0208")
     (bg-main "#0d0208")
     (bg-mark-delete "#190a10")
     (bg-mark-select "#003b00")
     (bg-mode-line-active "#001900")
     (bg-mode-line-inactive "#001900")
     (bg-prominent-err "#190a10")
     (bg-prompt unspecified)
     (bg-prose-block-contents "#001600")
     (bg-prose-block-delimiter bg-prose-block-contents)
     (bg-region "#003b00")
     (bg-removed "#190a10")
     (bg-removed-refine "#2b1520")
     (bg-tab-bar      "#001900")
     (bg-tab-current  bg-main)
     (bg-tab-other    "#001900")

     ;; borders
     (border-mode-line-active nil)
     (border-mode-line-inactive nil)

     ;; foreground semantic groups
     (builtin "#00ff41")
     (comment "#005a00")          ; dim green
     (constant  "#00ff41")
     (cursor  "#00ff41")
     (date-weekday "#00ff41")
     (date-weekend "#008f11")
     (docstring "#00c738")
     (err     "#00ff71")     ;; red is NOT in Matrix palette—using red for contrast
     (fg-active fg-main)
     (fg-completion "#00ff41")
     (fg-completion-match-0 "#00ff41")
     (fg-completion-match-1 "#00ff71")   ;; keeping semantic separation
     (fg-completion-match-2 "#00c738")
     (fg-completion-match-3 "#008f11")

     ;; headings mapped from bright → dark green gradient
     (fg-heading-0 "#00ff41")
     (fg-heading-1 "#00c738")
     (fg-heading-2 "#00a52a")
     (fg-heading-3 "#008f11")
     (fg-heading-4 "#005a00")

     (fg-line-number-active "#00ff41")
     (fg-line-number-inactive "#006600")
     (fg-link  "#00ff41")
     (fg-main "#00ff41")
     (fg-mark-delete "#00ff71")
     (fg-mark-select "#00ff41")
     (fg-mode-line-active "#00c738")
     (fg-mode-line-inactive "#005a00")
     (fg-prominent-err "#00ff71")
     (fg-prompt "#00ff41")
     (fg-prose-block-delimiter "#006600")
     (fg-prose-verbatim "#00c738")
     (fg-region "#00ff41")
     (fnname    "#00ff41")
     (fringe "#0d0208")
     (identifier "#00c738")
     (info    "#00ff41")
     (keyword   "#00c738")
     (keyword "#00c738")
     (name "#00ff41")
     (number "#008f11")
     (property "#00ff41")
     (string "#00c738")
     (type      "#00a52a")
     (variable  "#008f11")
     (warning "#00a52a")))
  :config
  (modus-themes-with-colors
    (custom-set-faces
     `(change-log-acknowledgment ((,c :foreground "#00c738")))
     `(change-log-date ((,c :foreground "#008f11")))
     `(change-log-name ((,c :foreground "#00a52a")))
     `(diff-context ((,c :foreground "#00ff41")))
     `(diff-file-header ((,c :foreground "#00c738")))
     `(diff-header ((,c :foreground "#00ff41")))
     `(diff-hunk-header ((,c :foreground "#008f11")))
     `(flymake-warning ((,c :foreground "#00a52a"
                            :underline (:color "#00a52a" :style wave))))
     `(flymake-note ((,c :foreground "#00ff41"
                         :underline (:color "#00ff41" :style wave))))
     `(link ((,c :foreground "#00ff41"
                 :underline (:color "#00ff41" :style line))))
     `(gnus-button ((,c :foreground "#00ff41")))
     `(gnus-group-mail-3 ((,c :foreground "#00ff41")))
     `(gnus-group-mail-3-empty ((,c :foreground "#00ff41")))
     `(gnus-header-content ((,c :foreground "#00c738")))
     `(gnus-header-from ((,c :foreground "#008f11")))
     `(gnus-header-name ((,c :foreground "#00c738")))
     `(gnus-header-subject ((,c :foreground "#00ff41")))
     `(log-view-message ((,c :foreground "#00c738")))
     `(match ((,c :background "#003b00" :foreground "#00ff41")))
     `(modus-themes-search-current ((,c :background "#00ff41" :foreground "#0d0208")))
     `(modus-themes-search-lazy ((,c :background "#003b00" :foreground "#00ff41")))
     `(newsticker-extra-face ((,c :foreground "#005a00" :height 0.8 :slant italic)))
     `(newsticker-feed-face ((,c :foreground "#00a52a" :height 1.2 :weight bold)))
     `(newsticker-treeview-face ((,c :foreground "#00ff41")))
     `(newsticker-treeview-selection-face ((,c :background "#003b00" :foreground "#00ff41")))
     `(tab-bar ((,c :background "#001900" :foreground "#00c738")))
     `(tab-bar-tab ((,c :background "#0d0208")))
     `(tab-bar-tab-group-current ((,c :background "#0d0208" :foreground "#00c738")))
     `(tab-bar-tab-group-inactive ((,c :background "#0d0208" :foreground "#005a00")))
     `(tab-bar-tab-inactive ((,c :background "#0d0208" :foreground "#008f11")))
     `(vc-dir-file ((,c :foreground "#00ff41")))
     `(vc-dir-header-value ((,c :foreground "#00c738")))))
  :init
  (load-theme 'modus-vivendi t))

;;;  nil theme: reset all custom face overrides set by other themes
;;
;; When no emacs-nxs theme is selected, any faces previously saved to
;; custom-vars.el by a theme's `custom-set-faces' call will persist across
;; restarts.  This block explicitly clears them so Emacs falls back to its
;; default/built-in face definitions.
(when (null emacs-nxs-use-custom-theme)
  (dolist (face '(change-log-acknowledgment
                  change-log-date
                  change-log-name
                  diff-context
                  diff-file-header
                  diff-header
                  diff-hunk-header
                  flymake-note
                  flymake-warning
                  gnus-button
                  gnus-group-mail-3
                  gnus-group-mail-3-empty
                  gnus-header-content
                  gnus-header-from
                  gnus-header-name
                  gnus-header-subject
                  link
                  log-view-message
                  match
                  modus-themes-search-current
                  modus-themes-search-lazy
                  newsticker-extra-face
                  newsticker-feed-face
                  newsticker-treeview-face
                  newsticker-treeview-selection-face
                  tab-bar
                  tab-bar-tab
                  tab-bar-tab-group-current
                  tab-bar-tab-group-inactive
                  tab-bar-tab-inactive
                  vc-dir-file
                  vc-dir-header-value))
    ;; Clear the 'user theme entry that custom-set-faces wrote — it has
    ;; higher priority than defface and would otherwise override the reset.
    (put face 'customized-face nil)
    (custom-push-theme 'theme-face face 'user 'reset)
    (face-spec-recalc face (selected-frame))))

(provide 'emacs-nxs-themes)
;;; emacs-nxs-themes.el ends here
